import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  normalizeChemicalNomenclature,
  detectDomainAndGrade,
  generateDetailedExplanation,
  parseWordContentToQuestions,
  SAMPLE_WORD_QUIZ_TEXT,
} from '../wordQuestionParser.ts';

describe('wordQuestionParser', () => {
  it('normalizes legacy Vietnamese chemical terms to IUPAC standard', () => {
    const res = normalizeChemicalNomenclature(
      'Cho kim loại natri tác dụng với axit clohidric và khí oxi.'
    );
    assert.equal(res.changed, true);
    assert.match(res.text, /Sodium \(Na\)/);
    assert.match(res.text, /Hydrochloric acid \(HCl\)/);
    assert.match(res.text, /Oxygen/);
  });

  it('detects domain, grade, and difficulty accurately from question text', () => {
    const phys = detectDomainAndGrade(
      'Tính cường độ dòng điện chạy qua điện trở R = 10 Ω theo định luật Ohm lớp 9.'
    );
    assert.equal(phys.domain, 'vat-li');
    assert.equal(phys.grade, 9);
    assert.equal(phys.difficulty, 'Vận dụng');

    const bio = detectDomainAndGrade(
      'Bào quan nào thực hiện chức năng quang hợp trong tế bào thực vật lớp 6?'
    );
    assert.equal(bio.domain, 'sinh-hoc');
    assert.equal(bio.grade, 6);
  });

  it('generates detailed scientific explanations when explanation is missing', () => {
    const exp = generateDetailedExplanation({
      question: 'Trong mô hình nguyên tử Rutherford - Bohr, hạt mang điện tích âm là hạt nào?',
      options: ['Proton', 'Neutron', 'Electron', 'Hạt nhân'],
      correctAnswer: 2,
      domain: 'hoa-hoc',
      grade: 7,
    });
    assert.match(exp, /Đáp án đúng là C \(Electron\)/);
    assert.match(exp, /Rutherford – Bohr/);
  });

  it('parses SAMPLE_WORD_QUIZ_TEXT with multiple-choice, essay questions, and step-by-step explanations', () => {
    const result = parseWordContentToQuestions(SAMPLE_WORD_QUIZ_TEXT, {
      defaultGrade: 8,
      defaultDomain: 'hoa-hoc',
      autoStandardizeIupac: true,
    });

    assert.equal(result.questions.length, 6);
    assert.equal(result.questions[0].correctAnswer, 0); // *A
    assert.equal(result.questions[1].correctAnswer, 1); // Đáp án: B
    assert.equal(result.questions[2].correctAnswer, 1); // Đáp án: B
    assert.equal(result.questions[3].correctAnswer, 1); // *B

    // Questions 5 and 6 are Essay questions (Tự luận) with image upload enabled
    assert.equal(result.questions[4].questionType, 'essay');
    assert.equal(result.questions[4].allowImageUpload, true);
    assert.equal(result.questions[5].questionType, 'essay');
    assert.equal(result.questions[5].allowImageUpload, true);

    // Every parsed question has a detailed explanation and multi-step solutionSteps
    for (const q of result.questions) {
      assert.ok(q.explanation.length > 40, `Expected detailed explanation for: ${q.question}`);
      assert.ok(
        Array.isArray(q.solutionSteps) && q.solutionSteps.length >= 2,
        `Expected step-by-step solutionSteps for: ${q.question}`
      );
    }

    // Legacy chemical names in Q2 were standardized to IUPAC and Q5 has Zn + 2HCl
    assert.match(result.questions[1].question, /Sodium hydroxide \(NaOH\)/);
    assert.match(result.questions[4].question, /ZnCl₂/);
    assert.match(result.questions[4].explanation, /\\frac\{6,5\}\{65\} = 0,1 mol/);
  });

  it('parses global BẢNG ĐÁP ÁN at the bottom of a Word document', () => {
    const docText = `
Câu 1: Công thức định luật Ohm là gì?
A. I = U . R
B. I = U / R
C. I = R / U
D. U = I / R

Câu 2: Môi trường Acid có giá trị pH như thế nào?
A. pH = 7
B. pH > 7
C. pH < 7
D. pH = 14

BẢNG ĐÁP ÁN
1.B   2-C
`;
    const result = parseWordContentToQuestions(docText);
    assert.equal(result.questions.length, 2);
    assert.equal(result.questions[0].correctAnswer, 1); // B
    assert.equal(result.questions[1].correctAnswer, 2); // C
    assert.equal(result.questions[0].detectedAnswerSource, 'answer_table');
    assert.equal(result.questions[1].detectedAnswerSource, 'answer_table');
  });

  it('concretely solves specific physics, chemistry, and biology exercises with actual numbers and stacked fractions', () => {
    const ohmExp = generateDetailedExplanation({
      question:
        'Đặt hiệu điện thế U = 24 V vào hai đầu đoạn mạch gồm R₁ = 4 Ω và R₂ = 8 Ω mắc nối tiếp. Tính cường độ dòng điện và công suất.',
      options: ['I = 2 A và P = 48 W', 'I = 3 A và P = 72 W'],
      correctAnswer: 0,
      domain: 'vat-li',
      grade: 9,
    });
    assert.match(ohmExp, /Dữ kiện:/);
    assert.match(ohmExp, /R_\{tđ\} = R₁ \+ R₂ = 4 \+ 8 = 12 Ω/);
    assert.match(ohmExp, /I = \\frac\{U\}\{R_\{tđ\}\} = \\frac\{24\}\{12\} = 2 A/);
    assert.match(ohmExp, /P = U × I = 24 × 2 = 48 W/);

    const chemExp = generateDetailedExplanation({
      question:
        'Cho 13 gam Zinc (Zn = 65) tác dụng với dung dịch Hydrochloric acid (HCl) dư. Tính thể tích khí Hydrogen ở đkc.',
      options: ['4,958 lít', '2,479 lít'],
      correctAnswer: 0,
      domain: 'hoa-hoc',
      grade: 8,
    });
    assert.match(chemExp, /Dữ kiện: m\(Zn\) = 13 g/);
    assert.match(chemExp, /\\frac\{13\}\{65\} = 0,2 mol/);
    assert.match(chemExp, /0,2 × 24,79 = 4,958 L/);
  });

  it('verifies all 6 acceptance criteria: Ohm inference, edit & regenerate, conflict detection, preserve provided vs single regenerate, and missing data', async () => {
    const { regenerateImportedQuestion, generateScientificSolution } = await import('../wordQuestionParser.ts');

    // 1. U = 12 V, R = 6 Ω -> options 1 A, 2 A, 3 A, 4 A -> inferred B (index 1), I = U/R = 12/6 = 2 A
    const raw1 = `Câu 1: Đặt hiệu điện thế U = 12 V vào hai đầu dây dẫn có điện trở R = 6 Ω. Hỏi cường độ dòng điện là bao nhiêu?
A. 1 A
B. 2 A
C. 3 A
D. 4 A`;
    const parsed1 = parseWordContentToQuestions(raw1).questions[0];
    assert.equal(parsed1.correctAnswer, 1); // B
    assert.equal(parsed1.solutionStatus, 'solved');
    assert.match(parsed1.explanation, /I = \\frac\{U\}\{R\} = \\frac\{12\}\{6\} = 2 A/);
    assert.match(parsed1.explanation, /Đối chiếu từng phương án:/);
    assert.match(parsed1.explanation, /Kết luận: Chọn B\./);

    // 2. Edit U from 12 V to 6 V -> regenerate -> inferred A (index 0, 1 A)
    const editedQ = {
      ...parsed1,
      question: parsed1.question.replace('U = 12 V', 'U = 6 V'),
    };
    const regenQ = regenerateImportedQuestion(editedQ, false);
    assert.equal(regenQ.correctAnswer, 0); // A (1 A)
    assert.equal(regenQ.solutionStatus, 'solved');
    assert.match(regenQ.explanation, /\\frac\{6\}\{6\} = 1 A/);

    // 3. Teacher selects conflicting answer (e.g., C = 3 A when calculation is 2 A)
    const conflictSol = generateScientificSolution({
      question: parsed1.question,
      options: parsed1.options,
      correctAnswer: 2, // C
      domain: 'vat-li',
      grade: 9,
    });
    assert.equal(conflictSol.status, 'needs_review');
    assert.ok(conflictSol.warnings.some((w) => w.includes('mâu thuẫn')));

    // 4. Bulk regenerate preserves Word/teacher explanation, while single regenerate replaces it
    const withTeacherExp = parseWordContentToQuestions(`${raw1}\nĐáp án: B\nLời giải: Ta có I = U/R = 12/6 = 2 A. Chọn B.`).questions[0];
    assert.equal(withTeacherExp.autoGeneratedExplanation, false);
    const bulkKept = regenerateImportedQuestion(withTeacherExp, true);
    assert.equal(bulkKept.autoGeneratedExplanation, false);
    assert.match(bulkKept.explanation, /Lời giải từ tài liệu\/giáo viên:/);
    const singleReplaced = regenerateImportedQuestion(withTeacherExp, false);
    assert.equal(singleReplaced.autoGeneratedExplanation, true);
    assert.match(singleReplaced.explanation, /Đáp án đúng là B \(2 A\)\./);

    // 5. Missing data or unsupported question -> needs_review, correctAnswer = -1 (not defaulting to A)
    const unsupportedRaw = `Câu 2: Một mạch điện có hiệu điện thế U = 12 V nhưng chưa biết điện trở. Cường độ dòng điện là bao nhiêu?
A. 1 A
B. 2 A
C. 3 A
D. 4 A`;
    const unsupportedQ = parseWordContentToQuestions(unsupportedRaw).questions[0];
    assert.equal(unsupportedQ.correctAnswer, -1);
    assert.equal(unsupportedQ.solutionStatus, 'needs_review');
    assert.ok(unsupportedQ.solutionWarnings && unsupportedQ.solutionWarnings.length > 0);
  });
});


